
from django.urls import path,include
from .views import *


urlpatterns = [

    path('',home , name="Home"),
    path('login',login , name="Login"),
    path('register',register , name="Register"),
    path('details',details, name="Details")
]
